
#include "spkm.h"

#if !defined(LARGE)
#define LARGE 1.0e50
#endif

#if !defined(OSKM_H)
#define OSKM_H

/* spherical online k-means clustering with weighted data samples
 * note: we require all data weights be integers and the smallest
 * weight be 1 */
int spkmo(struct CLUSTER *clust, int maxi, int learning, double eta0,
          double etaf, const int *wd, double *mcs, int fast);

#endif /* #if !defined(OSKM_H) */

