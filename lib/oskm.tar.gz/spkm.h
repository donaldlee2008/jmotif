
#if !defined(MIN)
#define MIN(A, B)   ((A) < (B) ? (A) : (B))
#endif

#if !defined(MAX)
#define MAX(A, B)   ((A) > (B) ? (A) : (B))
#endif

#if !defined(SPKM_H)
#define SPKM_H

/* to define a CLUSTER data type */
struct CLUSTER {
	int dim; /* data dimensionality */
	int N; /* number of data points */
	int nnz; /* number of non-zero entries in a sparse matrix */
	int *col; /* column index for sparse matrix */
	int *row; /* row index for sparse matrix */
	double *data; /* stored sample by sample, NOT dimension by dimension */
	double *wt; /* feature dimension weighting vector */
	int K; /* number of clusters */
	int *cid; /* cluster identity vector */
	double *centers; /* cluster centers */
	double qerr;
};

/* from sokm.c */

int compint2(const void *p1, const void *p2);

double dotprod(const double *x, const double *y, int d);

void unitnorm(double *x, int d);

int read_data(char *fdbfile, struct CLUSTER *clust);

int write_cluster(struct CLUSTER *clust, char *cfname);

int read_cluster(char *cfname, double *mv, int *pd, int *pkc);

int write_index(struct CLUSTER *clust, char *ifname);

int read_index(char *ifname, int *ci, int n);

void printusage(char *name);

/* scale data with log-IDF weights and L2-normalize data */
void scale_data(struct CLUSTER *clust);

/* Initialize clust->centers
 * init = 0 --> perturbing global mean
 * init = 1 --> KKZ initialization
 */
void spkm_init(struct CLUSTER *clust, int *wd, int init);

/* spherical batch k-means clustering with weighted data samples
 * note: we require all data weights be integers and the smallest
 *       weight be 1 */
int spkm(struct CLUSTER *clust, int maxi, double relerr,
		const int *wd, double *mcs, int init);

#endif /* #if !defined(SPKM_H) */

