/*****************************************************************************
 * oskm_main.c
 *
 * An implementation of the spherical online k-means clustering algorithm.
 * WTA competitive learning with exponential learning rate is used.
 *
 * by Shi Zhong, September 2004 (revised September 2005)
 *
 * Reference:
 * Shi Zhong, "Efficient Online Spherical K-means Clustering," In Proc. IEEE
 * Int. Joint Conf. Neural Networks, pp. 3081-3085, Montreal, Canada, 2005.
 *
 *****************************************************************************/

#include <math.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <sys/resource.h>

#include "oskm.h"

int verbose = 0;
int scale = 1;
int kkz = 1;


void printusage(char *name)
{
	printf("\nUsage: %s -K # -f file",name);
	printf(" <-v -fast -M # -eta0 # -etaf # ...>\n");
	printf("\nOptions:\n");
	printf("\t-K #   \tset number of clusters\n");
	printf("\t-f file\tset input file name\n");
	printf("\t-o file\tset output cluster file (default='input.c#K')\n");
	printf("\t-i file\tset output cluster index file (default='input.i#K')\n");
	printf("\t-c file\tset initial cluster file name (default=NONE)\n");
	printf("\t-w file\tset feature weight file name (default=NONE)\n");
	printf("\t-dw file\tset instance weight file name (default=NONE)\n");
	printf("\t-M #   \tset maximum number of iterations (default=20)\n");
	printf("\t-eta0 #\tset initial learning rate (default=1)\n");
	printf("\t-etaf #\tset final learning rate (default=0.01)\n");
	printf("\t-p     \tinitialize with global perturbation (default=kkz)\n");
	printf("\t-v     \tset verbose mode ON (default=OFF)\n");
	printf("\t-fast  \tset fast mode ON (default=OFF)\n");
	printf("\t-h     \tdisplay more detailed help info\n\n");
}


/* parse arguments */
int parse_args(struct CLUSTER *clust, int *pmaxi,
		int *pfast, double *peta0, double *petaf,
		char *docfile, char *ofname, char *ifname,
		char *cfname, char *wfname, char *dwfname, int nargs, char *args[])
{
	int i;

	*pmaxi = 20;
	*pfast = 0;
	*peta0 = 1;
	*petaf = 0.01;
	strcpy(docfile,"");
	strcpy(ofname,"");
	strcpy(ifname,"");
	clust->N = 0;
	clust->K = 0;
	clust->dim = 0;

	i = 1;
	while (i < nargs) {
		if (strcmp(args[i],"-K")==0) {
			i++; clust->K = atoi(args[i]);
		}
		else if (strcmp(args[i],"-d")==0) {
			i++; clust->dim = atoi(args[i]);
		}
		else if (strcmp(args[i],"-M")==0) {
			i++; *pmaxi = atoi(args[i]);
		}
		else if (strcmp(args[i],"-N")==0) {
			i++; clust->N = atoi(args[i]);
		}
		else if (strcmp(args[i],"-eta0")==0) {
			i++; *peta0 = (double) atof(args[i]);
		}
		else if (strcmp(args[i],"-etaf")==0) {
			i++; *petaf = (double) atof(args[i]);
		}
		else if (strcmp(args[i],"-f")==0) {
			i++; strcpy(docfile,args[i]);
		}
		else if (strcmp(args[i],"-o")==0) {
			i++; strcpy(ofname,args[i]);
		}
		else if (strcmp(args[i],"-i")==0) {
			i++; strcpy(ifname,args[i]);
		}
		else if (strcmp(args[i],"-c")==0) {
			i++; strcpy(cfname,args[i]);
		}
		else if (strcmp(args[i],"-w")==0) {
			i++; strcpy(wfname,args[i]);
		}
		else if (strcmp(args[i],"-dw")==0) {
			i++; strcpy(dwfname,args[i]);
		}
		else if (strcmp(args[i],"-v")==0) {
			verbose = 1;
		}
		else if (strcmp(args[i],"-p")==0) {
			kkz = 0;
		}
		else if (strcmp(args[i],"-fast")==0) {
			*pfast = 1;
		}
		else if (strcmp(args[i],"-s")==0) {
			scale = 1;
		}
		else if (strcmp(args[i],"-h")==0) {
			printf("Input data file in CCS format\n");
			printf("\n");
			printf("Dimensional weight file format:\n");
			printf("\tweight(1)\n");
			printf("\tweight(2)\n");
			printf("\t......\n");
			printf("\tweight(K)\n");
			printf("\n");
			printf("Cluster (mv = mean vector) file format:\n");
			printf("\tdim K N\n");
			printf("\tmv(1,1) mv(2,1) ... mv(dim,1) \n");
			printf("\tmv(1,2) mv(2,2) ... mv(dim,2) \n");
			printf("\t......\n");
			printf("\tmv(1,K) mv(2,K) ... mv(dim,K) \n");
			printf("\n");
			printf("Cluster index file format:\n");
			printf("\tcluster_id(1)\n");
			printf("\tcluster_id(2)\n");
			printf("\t......\n");
			printf("\tcluster_id(N)\n\n");
		}
		else {
			printf("parse_args: Unknown option %s!\n",args[i]);
			return 1;
		}
		i++;
	}
	if (clust->K==0 || strcmp(docfile,"")==0 || nargs < 5) {
		printusage(args[0]);
		return 1;
	}
	if (strlen(ofname)==0) {
		sprintf(ofname,"%s.c%d",docfile,clust->K);
	}
	if (strlen(ifname)==0) {
		sprintf(ifname,"%s.i%d",docfile,clust->K);
	}

	return 0;
}


/* the main function for sokm.c */
int main(int argc, char *argv[])
{
	int i, j, n, d, maxi, mlen, init, fast;
	int *pint, *wd, *pi;
	double *pdouble, *p, *q, *mcs; 
	char docfile[256], ofname[256], indfname[256], fname[256];
	char cfname[256], wfname[256], dwfname[256];
	struct CLUSTER *clust;
	FILE *fid;
	clock_t t0;
	double tio, tkm;
	time_t tb, te;
	struct rusage ru;
	double eta0, etaf;

	clust = (struct CLUSTER *) malloc(sizeof(struct CLUSTER));
	clust->data = NULL;
	clust->cid = NULL;
	clust->centers = NULL;

	if (verbose) { printf("Parsing input arguments ...\n"); }

	/* parse arguments */
	strcpy(wfname,"");
	strcpy(dwfname,"");
	strcpy(cfname,"");
	strcpy(indfname,"");
	if (parse_args(clust,&maxi,&fast,&eta0,&etaf,docfile,ofname,
				indfname, cfname, wfname, dwfname, argc, argv)) {
		exit(1);
	}

	strcpy(fname, docfile);
	fid = fopen(strcat(fname,"_dim"),"r");
	fscanf(fid, "%d", &i); clust->dim = i;
	fscanf(fid, "%d", &i); clust->N = i;
	fscanf(fid, "%d", &i); clust->nnz = i;
	fclose(fid);

	/* allocate memory */
	mlen = clust->nnz + clust->dim * (clust->K + 1) + maxi;
	pdouble = (double *) malloc(sizeof(double)*mlen);
	if (pdouble == NULL) {
		printf("main: Cannot allocate memory for fdb array!\n");
		return 1;
	}
	clust->data = pdouble;
	clust->centers = pdouble + clust->nnz;
	clust->wt = clust->centers + clust->dim * clust->K;
	mcs = clust->wt + clust->dim;
	pint = (int *) malloc(sizeof(int)*(clust->nnz+clust->N*3+1));
	if (pint == NULL) {
		printf("main: Cannot allocate memory for pint!\n");
		return 1;
	}
	clust->cid = pint;
	wd = pint + clust->N;
	clust->row = wd + clust->N;
	clust->col = clust->row + clust->nnz;

	if (strcmp(cfname,"")==0) {
		init = 0;
	}
	else {
		read_cluster(cfname, clust->centers, NULL, NULL);
		init = 1;
	}

	if (strcmp(wfname,"")==0) {
		q = NULL;
	}
	else {
		if ((fid = fopen(wfname,"r")) == NULL) {
			printf("main: Cannot open %s!\n",wfname);
			return 1;
		}
		for (i=0,p=clust->wt; i<clust->dim; i++) {
			fscanf(fid,"%lf",p++);
		}
		fclose(fid);
		q = clust->wt;
	}

	if (verbose) { printf("Reading data from %s ...\n", docfile); }

	/* read data */
	t0 = clock();
	if (read_data(docfile, clust)) {
		free(pint); free(pdouble); free(clust); exit(1);
	}
	tio = ((double)(clock()-t0))/CLOCKS_PER_SEC;

	/* weighted dimensions/features */
	if (q != NULL) { /* if weights available */
		n = clust->N; d = clust->dim;
		for (j=0; j<clust->nnz; j++) {
			i = clust->row[j];
			clust->data[j] *= q[i];
		}
	}

	if (scale) { scale_data(clust); }

	if (strcmp(dwfname,"")==0) {
		for (i=0; i<clust->N; i++) { wd[i] = 1; }
	}
	else {
		if ((fid = fopen(dwfname,"r")) == NULL) {
			printf("main: Cannot open %s!\n",wfname);
			return 1;
		}
		for (i=0,pi=wd; i<clust->N; i++) {
			fscanf(fid,"%d",pi++);
		}
		fclose(fid);
	}

	if (verbose) { printf("Running k-means clustering ...\n"); }

	/* cluster data */
	getrusage(0,&ru);
	tb = ru.ru_utime.tv_sec;
	t0 = clock();
	if (init == 0) { spkm_init(clust,wd,kkz); }
	i = spkmo(clust,maxi,1,eta0,etaf,wd,mcs,fast);
	tkm = ((double)(clock()-t0))/CLOCKS_PER_SEC;
	getrusage(0,&ru);
	te = ru.ru_utime.tv_sec;
	if (difftime(te,tb) > 1000) { tkm = difftime(te,tb); }

	if (i != 0) {
		printf("k-means returns unsuccessfully!\n");
		free(pint); free(pdouble); free(clust); exit(1);
	}
	else { clust->qerr = *mcs; }

	if (verbose) { printf("Save clustering results to %s ...\n",ofname); }

	/* write clustering results */
	t0 = clock();
	write_cluster(clust, ofname);
	if (strcmp(indfname,"") != 0) {
		write_index(clust, indfname);
	}
	tio += ((double)(clock()-t0))/CLOCKS_PER_SEC;

	/* print out performance measures */
	printf("\tMean cosine similarity = %f\n",clust->qerr);
	printf("\tClustering time = %f seconds\n",tkm);
	printf("\tI/O time = %f seconds\n",tio);

	/* free memory */
	free(pint);
	free(pdouble);
	free(clust);

	return 0;
}

