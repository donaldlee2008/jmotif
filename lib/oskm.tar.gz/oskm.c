/*****************************************************************************
 * oskm.c
 *
 * An implementation of the spherical online k-means clustering algorithm.
 * WTA competitive learning with exponential learning rate is used.
 *
 * by Shi Zhong, September 2004 (revised September 2005)
 *
 * Reference:
 * Shi Zhong, "Efficient Online Spherical K-means Clustering," In Proc. IEEE
 * Int. Joint Conf. Neural Networks, pp. 3081-3085, Montreal, Canada, 2005.
 *
 *****************************************************************************/

#include <math.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "oskm.h"


/* spherical online k-means clustering with weighted data samples
 * note: we require all data weights be integers and the smallest
 *       weight be 1 */
int spkmo(struct CLUSTER *clust, int maxi, int learning, double eta0, double etaf,
		  const int *wd, double *mcs, int fast)
{
    /* local variables */
	const double *data;
	int *sinds, *pi, *ci, *nc, *nd, *row, *col, *nv;
    double *mv, *p, *pd, r, *mincos, *n2, nw, a, eta, tmp;
    int i, i2, j, j2, k, d, n, kc, h, h1, h2, nn;

	data = clust->data;
	row = clust->row;
	col = clust->col;
	mv = clust->centers;
	ci = clust->cid;
	d = clust->dim;
	n = clust->N;
	kc = clust->K;
    
	nw = 0.0;
	for (i=0; i<n; i++) { nw += (double) wd[i]; }

    /* allocate dynamic memory */
	sinds = (int *)malloc(sizeof(int)*(n*2+kc*3));
	if (sinds == NULL) { printf("Malloc for sinds failed.\n"); return 1; }
	nc = sinds + n*2;
	nd = nc + kc; nv = nd + kc;
	memset(sinds,0,sizeof(int)*(n*2+kc*3));

	mincos = (double *) malloc(sizeof(double)*kc*3);
	n2 = mincos + kc;
	for (i=0; i<kc*2; i++) { n2[i] = 1.0; }
	eta = eta0;
	if (learning == 1) { a = pow(etaf/eta0, 1.0/nw/maxi); }
    
    /* iterately relocate means */
    for (k=0; k<maxi; k++) { 
		if (learning == 2) { eta = eta0 / (1.0 + k); }

		/* randomize data order */
		for (i=0,pi=sinds; i<n; i++) {
			*pi++ = rand()*rand(); *pi++ = i;
		}
		qsort(sinds, n, sizeof(int)*2, compint2); 
		memset(nc,0,sizeof(int)*kc*2);
		for (j=0; j<kc; j++) { mincos[j] = 1.0; }
		if (fast) { nn = MAX(n*(k+1)/maxi, MIN(kc*100,n)); }
		else { nn = n; }

		for (i=0; i<nn; i++) {

			/* pick a data sample */
			i2 = sinds[i*2+1];
			if (wd[i2] == 0) { continue; }
			h1 = col[i2]; h2 = col[i2+1];

			tmp = 0.0; 
			for (j=0,p=mv; j<kc; j++,p+=d) { /* find cluster index */
				r = 0.0;
				for (h=h1; h<h2; h++) {	r += data[h] * p[row[h]]; }
				r /= n2[j+kc];
				if (r > tmp) { tmp = r; ci[i2] = j; }
			}
			j2 = ci[i2]; nc[j2]++; nv[j2]++;
			if (learning == 3) { eta = eta0 / nv[j2]; }
			if (learning == 4) { eta = eta0 / (1.0 + (nv[j2]*k)/((double) nn)); }

			/* keep a list of far away-from-center data records */
			for (j=0; j<kc; j++) {
				if (tmp < mincos[j]) {
					mincos[j] = tmp; nd[j] = i2; break;
				}
			}

			/* update winning codebook vector */
			p = mv + d*j2;
			tmp = eta * n2[j2+kc];
			r = 0.0;
			for (h=h1; h<h2; h++) {
				pd = p + row[h];
				r -= (*pd) * (*pd);
				*pd += tmp * data[h];
				r += (*pd) * (*pd);
			}
			n2[j2] += r;
			n2[j2+kc] = sqrt(n2[j2]); 
			for (j=1; j<wd[i2]; j++) {
				if (learning == 1) { eta *= a; }
				tmp = eta * n2[j2+kc]; r = 0.0;
				for (h=h1; h<h2; h++) {
					pd = p + row[h];
					r -= (*pd) * (*pd);
					*pd += tmp * data[h];
					r += (*pd) * (*pd);
				}
				n2[j2] += r;
				n2[j2+kc] = sqrt(n2[j2]);
			}

			if (n2[j2+kc] > LARGE) {
				tmp = n2[j2+kc];
				for (j=0; j<d; j++,p++) { *p /= tmp; }
				n2[j2] = 1.0; n2[j2+kc] = 1.0;
			}

			/* update learning rate eta */
			if (learning == 1) { eta *= a; }

		} /* for (i=0; i<n; i++) */
		if (learning==1 && i<n) { eta *= pow(a,n-i); }

		/* eliminate empty clusters */
		for (j=0,h=0; j<kc; j++) {
			if (nc[j] == 0) {
				h1 = col[nd[h]]; h2 = col[nd[h]+1];
				p = mv+d*j;
				memset(p,0,sizeof(double)*d);
				for (j2=h1; j2<h2; j2++) { p[row[j2]] = data[j2]; }
				n2[j] = 1.0; n2[j+kc] = 1.0;
				h++;
			}
		}

    } /* for (k=0; k<maxi; k++) */

	for (j=0,p=mv; j<kc; j++) {
		tmp = n2[j+kc];
		for (i=0; i<d; i++,p++) { *p /= tmp; }
	}
	*mcs = 0.0;
	for (i=0; i<n; i++) {
		a = 0.0; h1 = col[i]; h2 = col[i+1];
		for (j=0,p=mv; j<kc; j++,p+=d) {
			tmp = 0.0;
			for (h=h1; h<h2; h++) { tmp += data[h] * p[row[h]]; }
			if (tmp > a) { ci[i] = j; a = tmp; }
		}
		*mcs += a * wd[i];
	}
	*mcs /= nw;

    /* free dynamic memory */
    free(sinds);
    free(mincos);

    return 0;
}

