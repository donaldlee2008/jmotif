/*****************************************************************************
 * spkm.c
 *
 * Implements function defined in spkm.h
 *****************************************************************************/


#include <math.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "spkm.h"


/* scale data with log-IDF weights and L2-normalize data */
void scale_data(struct CLUSTER *clust)
{
	int i, j, d, n, *col, *row;
	double *df, *data;

	d = clust->dim; 
	n = clust->N;
	col = clust->col; 
	row = clust->row;
	data = clust->data;

	/* log-IDF */
	df = (double *) malloc(sizeof(double)*d);
	memset(df,0,sizeof(double)*d);
	for (i=0; i<n; i++) {
		for (j=col[i]; j<col[i+1]; j++) {
			df[row[j]] += 1.0;
		}
	}
	for (i=0; i<d; i++) {
		if (df[i] > 0.0) { df[i] = log(n / df[i]); }
	}
	for (i=0; i<n; i++) {
		for (j=col[i]; j<col[i+1]; j++) {
			data[j] *= df[row[j]];
		}
	}
	free(df);

	/* unit norm */
	for (i=0; i<n; i++) {
		j = col[i];
		unitnorm(data+j, col[i+1]-j);
	}
}


int compint2(const void *p1, const void *p2)
{
	int d;

	d = *((int *)p1) - *((int *)p2);
	if (d > 0) { return 1; }
	else if (d < 0) { return -1; }
	else { return 0; }
}


/* dot product between two d-dimensional vector x and y */
double dotprod(const double *x, const double *y, int d)
{
    int i;
    double result = 0.0;
    
    for (i=0; i<d; i++) { result += x[i] * y[i]; }

    return result;
}


/* normalize a d-dimensional vector to be of unit length */
void unitnorm(double *x, int d)
{
	int i;
	double result = 0.0;

	for (i=0; i<d; i++) { result += x[i] * x[i]; }
	if (result > 0.0) {
		result = sqrt(result);
		for (i=0; i<d; i++) { x[i] /= result; }
	}
}


/* read data */
int read_data(char *fdbfile, struct CLUSTER *clust)
{
	int i, n, nnz, *fdbbuf, *pi;	
	double *pd;
	char fname[256];
	FILE *fid;

	n = clust->N;
	nnz = clust->nnz;
	pd = clust->data;

	strcpy(fname, fdbfile);
	if ((fid = fopen(strcat(fname,"_col_ccs"),"r")) == NULL) {
		printf("read_data: Cannot open file %s!\n",fname);
		return 1;
	}
	pi = clust->col;
	for (i=0; i<n+1; i++) {	fscanf(fid, "%d\n", pi++); }
	fclose(fid);

	strcpy(fname, fdbfile);
	if ((fid = fopen(strcat(fname,"_row_ccs"),"r")) == NULL) {
		printf("read_data: Cannot open file %s!\n",fname);
		return 1;
	}
	pi = clust->row;
	for (i=0; i<nnz; i++) {	fscanf(fid, "%d\n", pi++); }
	fclose(fid);

	fdbbuf = (int *) malloc(sizeof(int)*nnz); 

	strcpy(fname, fdbfile);
	if ((fid = fopen(strcat(fname,"_txx_nz"),"r")) == NULL) {
		printf("read_data: Cannot open file %s_txx_nz!\n",fname);
		return 1;
	}
	pi = fdbbuf;
	for (i=0; i<nnz; i++) {	fscanf(fid, "%d\n", pi++); }

	for (i=0,pi=fdbbuf; i<nnz; i++,pd++,pi++) {
		*pd = (double) (*pi);
	}

	free(fdbbuf);
	return 0;
}


/* save cluster centers to the cluster file */
int write_cluster(struct CLUSTER *clust, char *cfname)
{
	int d, kc;
	FILE *fid;

	d = clust->dim;
	kc = clust->K;

	if ((fid = fopen(cfname,"wb")) == NULL) {
		printf("write_cluster: Cannot open file %s!\n",cfname);
		return 1;
	}
	if (fwrite(&d,sizeof(int),1,fid) < 1) {
		printf("write_cluster: Error occurred writing d to %s!\n",cfname);
		return 1;
	}
	if (fwrite(&kc,sizeof(int),1,fid) < 1) {
		printf("write_cluster: Error occurred writing kc to %s!\n",cfname);
		return 1;
	}
	if (fwrite(clust->centers,sizeof(double)*d,kc,fid) < kc) {
		printf("write_cluster: Error occurred writing mv to %s!\n",cfname);
		return 1;
	}
	fclose(fid);

	return 0;
}


/* save cluster centers to the cluster file */
int read_cluster(char *cfname, double *mv, int *pd, int *pkc)
{
	int d, kc;
	FILE *fid;

	if ((fid = fopen(cfname,"rb")) == NULL) {
		printf("read_cluster: Cannot open file %s!\n",cfname);
		return 1;
	}
	if (fread(&d,sizeof(int),1,fid) < 1) {
		printf("read_cluster: Error occurred reading d from %s!\n",cfname);
		return 1;
	}
	if (fread(&kc,sizeof(int),1,fid) < 1) {
		printf("read_cluster: Error occurred reading kc from %s!\n",cfname);
		return 1;
	}
	if (fread(mv,sizeof(double)*d,kc,fid) < kc) {
		printf("read_cluster: Error occurred reading mv from %s!\n",cfname);
		return 1;
	}
	fclose(fid);

	if (pd) { *pd = d; }
	if (pkc) { *pkc = kc; }

	return 0;
}


int write_index(struct CLUSTER *clust, char *ifname)
{
	int n;
	FILE *fid;

	n = clust->N;

	if ((fid = fopen(ifname,"wb")) == NULL) {
		printf("write_index: Cannot open file %s!\n",ifname);
		return 1;
	}
	if (fwrite(clust->cid,sizeof(int),n,fid) < n) {
		printf("write_index: Error occurred writing ci to %s!\n",ifname);
		return 1;
	}
	fclose(fid);

	return 0;
}



int read_index(char *ifname, int *ci, int n)
{
	FILE *fid;

	if ((fid = fopen(ifname,"rb")) == NULL) {
		printf("read_index: Cannot open file %s!\n",ifname);
		return 1;
	}
	if (fread(ci,sizeof(int),n,fid) < n) {
		printf("read_index: Error occurred reading ci from %s!\n",ifname);
		return 1;
	}
	fclose(fid);

	return 0;
}


/* Initialize clust->centers
 * init = 0 --> perturbing global mean
 * init = 1 --> KKZ initialization
 */
void spkm_init(struct CLUSTER *clust, int *wd, int init)
{
    /* local variables */
	const double *data;
	int *row, *col;
    double *mv, *p, *sim, r, rmin;
    int i0, j0, i, j, k, d, n, kc, ind;

	data = clust->data;
	row = clust->row;
	col = clust->col;
	mv = clust->centers;
	d = clust->dim;
	n = clust->N;
	kc = clust->K;
    
	/* calculating global mean */
	memset(mv,0,sizeof(double)*d*kc);
	p = mv + d*(kc-1); /* save the global mean as the last mean vector */
	for (i=0; i<n; i++) {
		for (j=col[i]; j<col[i+1]; j++) {
			p[row[j]] += data[j] * wd[i];
		}
	}
	unitnorm(p,d);

    if (init == 0) {
        /* initialize mean vectors by perturbing the global mean */
        srand(rand()*((int)time(NULL)));
        p = mv + d;
        for (k=1; k<kc; k++) {
			memcpy(p,mv,sizeof(double)*d);
            for (j=0; j<d; j++,p++) {
                r = 1 + ((double) rand()/RAND_MAX - 0.5)/10;
                *p *= r;
            }
        }
		/* normalize each cluster center vector to be of unit length */
		for (k=0,p=mv; k<kc; k++,p+=d) { unitnorm(p,d); }
    }
	else {
        /* initialize mean vectors by KKZ method */
		/* the first mean vector is the instance that is most distant 
		to the global mean */
		rmin = 1;
		for (i=0; i<n; i++) {
			r = 0;
			for (j=col[i]; j<col[i+1]; j++) {
				r += data[j] * p[row[j]];
			}
			if (r < rmin) { ind = i; rmin = r; }
		}
		memset(p, 0, sizeof(double)*d); /* get rid of the global mean */
		/* ind is the index of the most distant instance */
		for (j=col[ind]; j<col[ind+1]; j++) {
			mv[row[j]] = data[j];
		}

		/* each subsequent mean vector is set to be the instance that
		is most distant to the closest previous mean vectors */
		sim = (double *) malloc(sizeof(double)*n);
		for (i0=1; i0<kc; i0++) {
			memset(sim,0,sizeof(double)*n);
			for (j0=0; j0<i0; j0++) {
				p = mv + d*j0;
				for (i=0; i<n; i++) {
					r = 0;
					for (j=col[i]; j<col[i+1]; j++) {
						r += data[j] * p[row[j]];
					}
					/* keep the maximum similarity (to existing clusters)
					for each instance */
					if (r > sim[i]) { sim[i] = r; }
				}
			}
			/* find the most distant/dissimilar instance */
			rmin = sim[0]; ind = 0;
			for (i=1; i<n; i++) {
				if (rmin > sim[i]) { rmin = sim[i]; ind = i; }
			}
			p = mv + d*i0;
			for (j=col[ind]; j<col[ind+1]; j++) {
				p[row[j]] = data[j];
			}
		}
		free(sim);
	}
    
}


/* spherical batch k-means clustering with weighted data samples
 * note: we require all data weights be integers and the smallest
 *       weight be 1 */
int spkm(struct CLUSTER *clust, int maxi, double relerr,
		const int *wd, double *mcs, int init)
{
    /* local variables */
	const double *data;
	int *sinds, *ci, *nc, *nd, *row, *col;
    double *mv, *p, r, *mincos, *n2, nw, tmp;
    int i, j, j2, k, d, n, kc, h, h1, h2;

	data = clust->data;
	row = clust->row;
	col = clust->col;
	mv = clust->centers;
	ci = clust->cid;
	d = clust->dim;
	n = clust->N;
	kc = clust->K;
    
	nw = 0.0;
	for (i=0; i<n; i++) { nw += (double) wd[i]; }

    if (init == 0) {
        /* initialize mean vectors by perturbing the global mean */
		memset(mv,0,sizeof(double)*d*kc);
		for (i=0; i<n; i++) {
			for (j=col[i]; j<col[i+1]; j++) {
				mv[row[j]] += data[j] * wd[i];
			}
		}
        srand(rand()*((int)time(NULL)));
        p = mv + d;
        for (k=1; k<kc; k++) {
			memcpy(p,mv,sizeof(double)*d);
            for (j=0; j<d; j++,p++) {
                r = 1 + ((double) rand()/RAND_MAX - 0.5)/10;
                *p *= r;
            }
        }
		/* normalize each cluster center vector to be of unit length */
		for (k=0,p=mv; k<kc; k++,p+=d) { unitnorm(p,d); }
    }
    
    /* allocate dynamic memory */
	sinds = (int *)malloc(sizeof(int)*(kc*2));
	if (sinds == NULL) { printf("Malloc for sinds failed.\n"); return -1; }
	nc = sinds;
	nd = nc + kc;

	mincos = (double *) malloc(sizeof(double)*kc*(d+1));
	if (mincos == NULL) { printf("Malloc for mincos failed.\n"); return -1; }
	n2 = mincos + kc;
	memset(mcs,0,sizeof(double)*kc);

    /* iterately relocate means */
    for (k=0; k<maxi; k++) { 

		memset(nc,0,sizeof(int)*kc);
		memset(nd,-1,sizeof(int)*kc);
		memset(n2,0,sizeof(double)*kc*d);
		for (j=0; j<kc; j++) { mincos[j] = 1.0; }

		for (i=0; i<n; i++) {

			if (wd[i] == 0) { continue; }
			h1 = col[i]; h2 = col[i+1];

			tmp = 0.0; 
			for (j=0,p=mv; j<kc; j++,p+=d) { /* find cluster index */
				r = 0.0;
				for (h=h1; h<h2; h++) {	r += data[h] * p[row[h]]; }
				if (r > tmp) { tmp = r; ci[i] = j; }
			}
			nc[ci[i]]++; mcs[k] += tmp;
			p = n2 + d * ci[i];
			for (h=h1; h<h2; h++) { p[row[h]] += data[h]*wd[i]; }

			/* keep a list of far away-from-center data records */
			for (j=0; j<kc; j++) {
				if (tmp < mincos[j]) {
					mincos[j] = tmp; nd[j] = i; break;
				}
			}

		} /* for (i=0; i<n; i++) */

		if (k > 0) {
			if (mcs[k] - mcs[k-1] < relerr * mcs[k-1]) { break; }
		}

		memcpy(mv, n2, sizeof(double)*d*kc);

		/* eliminate empty clusters */
		for (j=0,h=0; j<kc; j++) {
			p = mv+d*j;
			if (nc[j] == 0 && nd[h] >= 0) {
				h1 = col[nd[h]]; h2 = col[nd[h]+1];
				memset(p,0,sizeof(double)*d);
				for (j2=h1; j2<h2; j2++) { p[row[j2]] = data[j2]; }
				h++;
			}
			else { unitnorm(p,d); }
		}

    } /* for (k=0; k<maxi; k++) */
	h = k;

/*	*mcs = 0.0;
	for (i=0; i<n; i++) {
		a = 0.0; h1 = col[i]; h2 = col[i+1];
		for (j=0,p=mv; j<kc; j++,p+=d) {
			tmp = 0.0;
			for (h=h1; h<h2; h++) { tmp += data[h] * p[row[h]]; }
			if (tmp > a) { ci[i] = j; a = tmp; }
		}
		*mcs += a * wd[i];
	}
	*mcs /= nw;
*/

	for (k=0; k<maxi; k++) { mcs[k] /= nw; }

    /* free dynamic memory */
    free(sinds);
    free(mincos);

    return h;
}

